//  Created by Eugene Rivera on 12/3/15.


#include "Row_Column.hpp"

Row_Column::Row_Column(int row, int column){
    _row = row;
    _column = column;
}

