Everything is working, move with w, a, s, d.
Executable: ./game.x 10 40
or ./game 25 80
Enjoy!